import heapq

goal = [[1,2,3],[4,5,6],[7,8,0]]
start = [[1,2,3],[4,0,6],[7,5,8]]

def h(state):
    count = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != 0 and state[i][j] != goal[i][j]:
                count += 1
    return count


def neighbors(state):
    result = []

    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                x, y = i, j

    for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
        nx, ny = x+dx, y+dy

        if 0 <= nx < 3 and 0 <= ny < 3:
            temp = [row[:] for row in state]

            temp[x][y], temp[nx][ny] = temp[nx][ny], temp[x][y]

            result.append(temp)

    return result


pq = []
heapq.heappush(pq, (h(start), start))

visited = []

while pq:
    _, current = heapq.heappop(pq)

    print(current)

    if current == goal:
        print("Goal Reached")
        break

    visited.append(current)

    for n in neighbors(current):
        if n not in visited:
            heapq.heappush(pq, (h(n), n))