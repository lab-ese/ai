from collections import deque

jug1 = 4
jug2 = 3
target = 2
visited = set()


def dfs(state):
    if state in visited:
        return False

    visited.add(state)
    x, y = state
    print(state)

    if x == target or y == target:
        return True

    next_states = [
        (jug1, y),
        (x, jug2),
        (0, y),
        (x, 0),
        (max(0, x-(jug2-y)), min(jug2, x+y)),
        (min(jug1, x+y), max(0, y-(jug1-x)))
    ]

    for s in next_states:
        if dfs(s):
            return True

    return False


dfs((0,0))
