states = ['A','B','C','D']
colors = ['Red','Green','Blue']

neighbors = {
    'A':['B','C'],
    'B':['A','D'],
    'C':['A','D'],
    'D':['B','C']
}

solution = {}


def valid(state, color):
    for n in neighbors[state]:
        if solution.get(n) == color:
            return False
    return True


def solve(i):
    if i == len(states):
        return True

    state = states[i]

    for color in colors:
        if valid(state, color):
            solution[state] = color

            if solve(i+1):
                return True

            del solution[state]

    return False

solve(0)
print(solution)
