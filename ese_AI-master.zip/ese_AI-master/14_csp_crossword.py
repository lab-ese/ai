words = ["APPLE", "ALIVE", "EVADE", "EAGLE"]

grid = [[" "]*5 for _ in range(5)]

slots = [
    (0,0,"H"),
    (0,0,"V"),
    (0,4,"V"),
    (4,0,"H")]


def place(word, r, c, d):
    old = []
    for i in range(5):
        x, y = (r, c+i) if d=="H" else (r+i, c)
        if grid[x][y] not in [" ", word[i]]:
            return False
        old.append(grid[x][y])

    for i in range(5):
        x, y = (r, c+i) if d=="H" else (r+i, c)
        grid[x][y] = word[i]
    return old

def remove(old, r, c, d):

    for i in range(5):
        x, y = (r, c+i) if d=="H" else (r+i, c)
        grid[x][y] = old[i]


def solve(i):
    if i == len(slots):
        return True

    r, c, d = slots[i]

    for word in words:
        old = place(word, r, c, d)
        if old:
            if solve(i+1):
                return True
            remove(old, r, c, d)
    return False


solve(0)
for row in grid:
    print(row)