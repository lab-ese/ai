import math

board = [' ']*9

def check(p):
    wins = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
    return any(board[a]==board[b]==board[c]==p for a,b,c in wins)

def minimax(is_max):
    if check('O'): return 1
    if check('X'): return -1
    if ' ' not in board: return 0

    if is_max:
        best = -math.inf
        for i in range(9):
            if board[i]==' ':
                board[i]='O'
                best = max(best, minimax(False))
                board[i]=' '
        return best

    best = math.inf
    for i in range(9):
        if board[i]==' ':
            board[i]='X'
            best = min(best, minimax(True))
            board[i]=' '
    return best

def best_move():
    best, move = -math.inf, 0
    for i in range(9):
        if board[i]==' ':
            board[i]='O'
            score = minimax(False)
            board[i]=' '
            if score > best:
                best, move = score, i
    return move

while True:
    print(board[0:3], board[3:6], board[6:9])

    pos = int(input("Enter position (0-8): "))
    board[pos] = 'X'

    if check('X'):
        print("You Win")
        break

    if ' ' not in board:
        print("Draw")
        break

    ai = best_move()
    board[ai] = 'O'
    print("AI chose", ai)

    if check('O'):
        print("AI Wins")
        break