from queue import PriorityQueue

graph = {
    'Pune':[('Mumbai',2),('Nashik',4)],
    'Mumbai':[('Goa',3)],
    'Nashik':[('Goa',1)],
    'Goa':[]
}

heuristic = {'Pune':4,'Mumbai':2,'Nashik':1,'Goa':0}

pq = PriorityQueue()
pq.put((0, 0, 'Pune'))  # f, g, node
visited = {}

while not pq.empty():
    f, g, node = pq.get()

    if node in visited and visited[node] <= g:
        continue

    visited[node] = g
    print(node, "g=", g)

    if node == 'Goa':
        break

    for neigh, cost in graph[node]:
        new_g = g + cost
        f = new_g + heuristic[neigh]
        pq.put((f, new_g, neigh))