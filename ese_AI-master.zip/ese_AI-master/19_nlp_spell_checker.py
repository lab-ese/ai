import nltk

vocab = ["artificial","intelligence","algorithm","python","machine","learning",
"photosynthesis","technology","heuristic","constraint","search","programming",
"software","database","system"]

word = input("Enter Word: ").lower()

if word in vocab:
    print(f"'{word}' is correct.")
else:
    cand = [w for w in vocab if abs(len(w)-len(word))<=1 and w[0]==word[0]]
    sug = sorted(cand, key=lambda w: nltk.edit_distance(word,w))[:3]
    print("Misspelled. Suggestions:" if sug else "No suggestions found.", ", ".join(sug))