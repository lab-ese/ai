board = [' ' for _ in range(9)]

def print_board():
    for i in range(0, 9, 3):
        print(board[i:i+3])


def check_win(player):
    wins = [(0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)]
    return any(board[a] == board[b] == board[c] == player for a,b,c in wins)


def best_move():
    for i in range(9):
        if board[i] == ' ':
            board[i] = 'O'
            if check_win('O'):
                return
            board[i] = ' '

    for i in range(9):
        if board[i] == ' ':
            board[i] = 'X'
            if check_win('X'):
                board[i] = 'O'
                return
            board[i] = ' '

    if board[4] == ' ':
        board[4] = 'O'
        return

    for i in [0,2,6,8]:
        if board[i] == ' ':
            board[i] = 'O'
            return

    for i in [1,3,5,7]:
        if board[i] == ' ':
            board[i] = 'O'
            return

while True:
    print_board()
    move = int(input("Enter position (0-8): "))
    board[move] = 'X'

    if check_win('X'):
        print("You win")
        break

    best_move()

    if check_win('O'):
        print_board()
        print("Computer wins")
        break
