import heapq

start = [[1,2,3],[4,0,6],[7,5,8]]
goal = [[1,2,3],[4,5,6],[7,8,0]]


def h(state):
    count = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != 0 and state[i][j] != goal[i][j]:
                count += 1
    return count


def neighbors(state):
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                x, y = i, j
    result = []
    for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
        nx, ny = x + dx, y + dy
        if 0 <= nx < 3 and 0 <= ny < 3:
            temp = [row[:] for row in state]
            temp[x][y], temp[nx][ny] = temp[nx][ny], temp[x][y]
            result.append(temp)
    return result


pq = []
heapq.heappush(pq, (h(start), 0, start))
visited = []

while pq:
    f, g, current = heapq.heappop(pq)
    print(current)

    if current == goal:
        print("Goal Reached")
        break
    visited.append(current)

    for n in neighbors(current):
        if n not in visited:
            new_g = g + 1
            heapq.heappush(pq, (new_g + h(n), new_g, n))