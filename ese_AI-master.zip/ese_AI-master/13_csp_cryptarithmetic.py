word1 = "SEND"
word2 = "MORE"
result = "MONEY"

letters = list(set(word1 + word2 + result))

mapping = {}
used = set()


def value(word):
    num = ""
    for ch in word:
        num += str(mapping[ch])
    return int(num)

def solve(i):

    if i == len(letters):
        if value(word1) + value(word2) == value(result):
            return True
        return False

    ch = letters[i]

    for d in range(10):
        if d not in used:
            if d == 0 and ch in [word1[0], word2[0], result[0]]:
                continue
            mapping[ch] = d
            used.add(d)

            if solve(i + 1):
                return True
            used.remove(d)
            del mapping[ch]

    return False

if solve(0):
    print(mapping)
    print(value(word1))
    print(value(word2))
    print(value(result))

else:
    print("No Solution")