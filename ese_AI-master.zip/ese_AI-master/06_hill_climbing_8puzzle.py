from copy import deepcopy

start = [[1,2,3],[4,0,6],[7,5,8]]
goal = [[1,2,3],[4,5,6],[7,8,0]]


def heuristic(state):
    dist = 0
    for i in range(3):
        for j in range(3):
            val = state[i][j]
            if val != 0:
                x = (val-1)//3
                y = (val-1)%3
                dist += abs(x-i)+abs(y-j)
    return dist


def neighbors(state):
    dirs = [(1,0),(-1,0),(0,1),(0,-1)]
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                x, y = i, j

    result = []
    for dx, dy in dirs:
        nx, ny = x+dx, y+dy
        if 0 <= nx < 3 and 0 <= ny < 3:
            temp = deepcopy(state)
            temp[x][y], temp[nx][ny] = temp[nx][ny], temp[x][y]
            result.append(temp)
    return result

current = start

while True:
    print(current)
    if current == goal:
        print("Goal reached")
        break

    next_states = neighbors(current)
    next_state = min(next_states, key=heuristic)

    if heuristic(next_state) >= heuristic(current):
        print("Stuck at local maxima")
        break

    current = next_state
