import nltk

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

text = input("Enter sentence: ")

words = nltk.word_tokenize(text)

tags = nltk.pos_tag(words)

for word, tag in tags:
    print(word, "->", tag)