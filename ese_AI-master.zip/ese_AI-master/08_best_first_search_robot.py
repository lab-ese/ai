from queue import PriorityQueue

graph = {
    'A':[('B',2),('C',1)],
    'B':[('D',5)],
    'C':[('D',1)],
    'D':[]
}

heuristic = {'A':3,'B':2,'C':1,'D':0}

pq = PriorityQueue()
pq.put((heuristic['A'], 'A'))
visited = set()

while not pq.empty():
    h, node = pq.get()

    if node in visited:
        continue

    visited.add(node)
    print(node)

    if node == 'D':
        break

    for neigh, cost in graph[node]:
        pq.put((heuristic[neigh], neigh))
