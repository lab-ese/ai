from collections import deque

jug1 = 4
jug2 = 3
target = 2
visited = set()
queue = deque([(0,0)])

while queue:
    x, y = queue.popleft()

    if (x, y) in visited:
        continue

    visited.add((x, y))
    print((x, y))

    if x == target or y == target:
        print("Target reached")
        break

    next_states = [
        (jug1, y),
        (x, jug2),
        (0, y),
        (x, 0),
        (max(0, x-(jug2-y)), min(jug2, x+y)),
        (min(jug1, x+y), max(0, y-(jug1-x)))
    ]

    for s in next_states:
        if s not in visited:
            queue.append(s)
