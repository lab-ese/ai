import math
from collections import Counter

def sim(t1, t2):
    w1, w2 = t1.lower().split(), t2.lower().split()
    v1, v2 = Counter(w1), Counter(w2)

    vocab = set(v1) | set(v2)

    dot = sum(v1[w] * v2[w] for w in vocab)
    m1 = math.sqrt(sum(x*x for x in v1.values()))
    m2 = math.sqrt(sum(x*x for x in v2.values()))
    cos = dot / (m1 * m2) if m1 and m2 else 0

    s1, s2 = set(w1), set(w2)
    jac = len(s1 & s2) / len(s1 | s2) if (s1 | s2) else 0

    return cos, jac


a = input("Sentence 1: ")
b = input("Sentence 2: ")

c, j = sim(a, b)

print("Cosine:", c)
print("Jaccard:", j)