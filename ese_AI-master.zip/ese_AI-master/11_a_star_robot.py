from queue import PriorityQueue
graph = {
    'A':[('B',1),('C',4)],
    'B':[('D',2)],
    'C':[('D',1)],
    'D':[]
}
heuristic = {'A':3,'B':2,'C':1,'D':0}
pq = PriorityQueue()

pq.put((0,0,'A'))

visited = set()

while not pq.empty():
    f,g,node = pq.get()
    if node in visited:
        continue
    visited.add(node)
    print(node, "cost =", g)

    if node == 'D':
        break

    for neigh,cost in graph[node]:
        new_g = g + cost
        h = heuristic[neigh]

        pq.put((new_g + h, new_g, neigh))