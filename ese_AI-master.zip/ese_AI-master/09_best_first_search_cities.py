from queue import PriorityQueue

cities = {
    'Pune':['Mumbai','Nashik'],
    'Mumbai':['Goa'],
    'Nashik':['Goa'],
    'Goa':[]
}

h = {'Pune':3,'Mumbai':1,'Nashik':2,'Goa':0}

pq = PriorityQueue()
pq.put((h['Pune'], 'Pune'))
visited = set()

while not pq.empty():
    _, city = pq.get()

    if city in visited:
        continue

    visited.add(city)
    print(city)

    if city == 'Goa':
        break

    for nxt in cities[city]:
        pq.put((h[nxt], nxt))
